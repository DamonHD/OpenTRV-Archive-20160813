nuts-n-bolts
============

Generation of 3D SCAD modules to create internal and external screw threads for nuts and bolts